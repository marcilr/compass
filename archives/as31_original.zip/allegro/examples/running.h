/* Allegro data file object indexes, produced by grabber v2.1 + WIP */
/* Datafile: c:\allegro\examples\running.dat */
/* Date: Sun Dec  1 19:24:13 1996 */
/* Do not hand edit! */

#define FRAME_01                         0        /* BMP  */
#define FRAME_02                         1        /* BMP  */
#define FRAME_03                         2        /* BMP  */
#define FRAME_04                         3        /* BMP  */
#define FRAME_05                         4        /* BMP  */
#define FRAME_06                         5        /* BMP  */
#define FRAME_07                         6        /* BMP  */
#define FRAME_08                         7        /* BMP  */
#define FRAME_09                         8        /* BMP  */
#define FRAME_10                         9        /* BMP  */
#define PALLETE_001                      10       /* PAL  */

